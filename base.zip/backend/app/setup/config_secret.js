module.exports = {
  development:{
    smtp_username:"projectdevan@gmail.com",
    smtp_password:"allworldisastage",
  },
  test:{
    db_name: 'test',
  },
  production:{
  }
}