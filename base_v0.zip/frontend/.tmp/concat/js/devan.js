
window.routes =
{
  "/login": {
    templateUrl: 'partials/login.html', 
    controller: 'loginCtrl', 
    requireLogin: false
  },
  "/reader": {
    templateUrl: 'partials/reader.html', 
    controller: 'readerCtrl', 
    requireLogin: false
  },
  "/movie": {
    templateUrl: 'partials/movie.html', 
    controller: 'movieCtrl', 
    requireLogin: false
  },
  "/notsandcross": {
    templateUrl: 'partials/notsandcross.html', 
    controller: 'notsandcrossCtrl', 
    requireLogin: false
  }
};
// Declare app level module which depends on filters, and services
var MyApp = angular.module('myApp', ['myApp.filters', 'myApp.services', 'myApp.directives', 
                            'myApp.controllers', 'ngResource', 'ngSanitize', 'ui.event']);
var MyAppControllers = angular.module('myApp.controllers', []);
var MyAppServices = angular.module('myApp.services',[]);

MyApp
.config(['$routeProvider', function($routeProvider) {
  for(var path in window.routes){
    $routeProvider.when(path, window.routes[path]);
  }
  $routeProvider.otherwise({redirectTo: '/login'});
}])
.run(['$rootScope', 'SessionService',function($rootScope, SessionService){
  $rootScope.$on("$locationChangeStart", function(event, next, current) {
    for(var i in window.routes) {
      if(next.indexOf(i) != -1) {
        if(window.routes[i].requireLogin && !SessionService.getUserAuthenticated()) {
          alert("You need to be authenticated to see this page!");
          event.preventDefault();
        }
      }
    }
  });
}]);

'use strict';

/* Services */


// Demonstrate how to register services
// In this case it is a simple value service.
MyAppServices.value('version', '0.1');

MyAppServices.service('SessionService', function(){
    var userIsAuthenticated = false;

    this.setUserAuthenticated = function(value){
      userIsAuthenticated = value;
    };

    this.getUserAuthenticated = function(){
      return userIsAuthenticated;
    };
  });

'use strict';

/* Controllers */

MyAppControllers.controller('loginCtrl', ['$scope', '$resource', '$location', 'SessionService', 
    function($scope, $resource, $location, SessionService) {
    $scope.loginMessage = "Not logged in";
    $scope.login = function(username,password){
      var outer = this;
      console.log("Button clicked", outer.username, outer.password);
      
      var serverAuth = $resource('api/v1/session/login', {}, 
        { login: {method:'POST', params:{username:outer.username,password:outer.password}} });
      serverAuth.login(function(response){
        //console.log("Login successful: ", response);
        SessionService.setUserAuthenticated(true);
        //console.log("User authenticated ", SessionService.getUserAuthenticated());
        $location.path( "/reader" );
      }, 
      function(err){
        //console.log("Login", JSON.stringify(err));
        $scope.loginMessage = "Login Failed "+err.data.message;
      });
    };
  }]);

'use strict';

/* Controllers */

MyAppControllers.controller('readerCtrl', ['$scope', '$resource', '$location', 'SessionService', 
                function($scope, $resource, $location, SessionService) {

    $scope.logout = function(){
      console.log("LogOut");
      SessionService.setUserAuthenticated(false);
      var serverAuth = $resource('api/v1/session/logout', {}, 
        { logout: {method:'GET'}});
      serverAuth.logout();
      $location.path( "/view1" );
    };
    
    var Subscriptions = $resource('reader/subscriptions',{}, {
      get: {method:'GET', isArray: true, headers: [{'Content-Type': 'application/json'}, {'Accept': 'application/json'}]}
      });
    $scope.subscriptions = Subscriptions.get();

    $scope.addFeedMessage = "Enter a rss feed";
    $scope.add = function(feed){
      var postSub = $resource('reader/subscriptions/xmlUrl',{}, {
        add: {method:'POST', headers: [{'Content-Type': 'application/json'}, {'Accept': 'application/json'}]}
      });
      postSub.add({},{url:feed}, function(response){
        console.log(response);
        $scope.addFeedMessage = "Feed added successfully: "+JSON.stringify(response.name);
        $scope.articles = response.articles;
        $scope.subscriptions = Subscriptions.get();
        $scope.feedUrl = null;
        $scope.listedSubscription = response;
      },
      function(err){
        console.log(err.data);
        console.log(JSON.stringify(err));
        $scope.addFeedMessage = "Error in adding feed:"+JSON.stringify(err.data);
      });
    };

    $scope.getArticle = function(subscription){
      console.log(JSON.stringify(subscription));
      var Articles = $resource('reader/articles/:id',{}, {
        get: {method:'GET', isArray: true, headers: [{'Accept': 'application/json'}]}
      });
      $scope.articles = Articles.get({id:subscription._id});
      $scope.listedSubscription = subscription;
    };

    $scope.scrollCallBack = function(){
      console.log("Scroll starts");
    };
    
    /* $scope.subscriptions = [
      {
        id: 909090909,
        name: 'IBN Live',
        type:'rss',
        subscriptionUrl:'https://',
        siteUrl:'https://',
        categories:['news','sports']
      }
    ];*/

 
  }]);

'use strict';

/* Controllers */

MyAppControllers.controller('movieCtrl', ['AssembleSceneService' ,
    function(AssembleSceneService) {
      var renderer = null, scene = null, camera = null, cube = null, animating = false;

      function onLoad()
      {
        // Grab our container div
        var container = document.getElementById("container");
        // Create the Three.js renderer, add it to our div
        renderer = new THREE.WebGLRenderer( { antialias: true } );
        renderer.setSize(container.offsetWidth, container.offsetHeight);
        container.appendChild( renderer.domElement );

        // Put in a camera
        camera = new THREE.PerspectiveCamera( 45,
        container.offsetWidth / container.offsetHeight, 1, 4000 );
        /* camera = new THREE.OrthographicCamera( 10 / - 2, 10 / 2, 
          10 / 2, 10 / - 2, 1, 1000 ); */
        camera.position.set( 0, 20, 300);
        //camera.lookAt(0, 2, 3);
        // Create a shaded, texture-mapped cube and add it to the scene
        // First, create the texture map
        var mapUrl = "img/flower.jpg";
        var map = THREE.ImageUtils.loadTexture(mapUrl);
        // Now, create a Phong material to show shading; pass in the map
        var material = new THREE.MeshPhongMaterial({ map: map });
        // Create the cube geometry
        var geometry = new THREE.CubeGeometry(1, 1, 1);
        // And put the geometry and material together into a mesh
        cube = new THREE.Mesh(geometry, material);
        // Turn it toward the scene, or we won't see the cube shape!
        cube.rotation.x = Math.PI / 5;
        cube.rotation.y = Math.PI / 5;
        // Add the cube to our scene
        //scene.add( cube );

        scene = AssembleSceneService.createSettingScene();

        // Add a mouse up handler to toggle the animation
        // Add a mouse up handler to toggle the animation
        addMouseHandler();
        // Run our render loop
        run();
      }
      function run()
      {
        // Render the scene
        render();
        // Spin the cube for next frame
        if (animating)
        {
        cube.rotation.y -= 0.01;
        }
        // Ask for another frame
        requestAnimationFrame(run);
      }
      function render() {

        var timer = Date.now() * 0.0001;

        camera.position.x = Math.cos( timer ) * 2;
        camera.position.z = Math.sin( timer ) * 2;
        camera.lookAt( scene.position );

        renderer.render( scene, camera );

      }
      function addMouseHandler()
      {
        var dom = renderer.domElement;
        dom.addEventListener( 'mouseup', onMouseUp, false);
      }
      function onMouseUp (event)
      {
        event.preventDefault();
        animating = !animating;
      }
      onLoad();
  }]);

'use strict';

MyAppServices.service('ShootingSetMeshService', function(){

	this.createSetOrientation = function(sizeVec3, rotationVec3, positionVec3){

		// Create the ground as Y Z Axis
		var plane = new THREE.Mesh( new THREE.PlaneGeometry( sizeVec3.x, sizeVec3.y, 100, 100), 
                    new THREE.MeshBasicMaterial( { color: 0xffffff, wireframe: true } ) );
		plane.rotation.x = Math.PI/2;

        // Create the X, Y, Z axis for orientation
        var material = new THREE.LineBasicMaterial( { color: 0xff0000, opacity: 1, linewidth: 10} );
        var geometry = new THREE.Geometry();
        geometry.vertices.push(new THREE.Vector3(0,0,0));
        geometry.vertices.push(new THREE.Vector3(0,0,0.25));
        geometry.vertices.push(new THREE.Vector3(0,0,0));
        geometry.vertices.push(new THREE.Vector3(0,0.5,0));
        geometry.vertices.push(new THREE.Vector3(0,0,0));
        geometry.vertices.push(new THREE.Vector3(1,0,0));
        var axis = new THREE.Line( geometry,  material, THREE.LinePieces );
        axis.position.x = -0.1;
        axis.position.z = -0.1;
        
        // Create a group and add above together
        var group = new THREE.Object3D();
        group.add(plane);
        group.add(axis);

        // rotate the group 
        group.rotation.x = rotationVec3.x;
        group.rotation.y = rotationVec3.y;
        group.rotation.z = rotationVec3.z;
        // offset the group
        group.position.x = positionVec3.x;
        group.position.y = positionVec3.y;
        group.position.z = positionVec3.z;

        return group;
	};
});
'use strict';

MyAppServices.service('AssembleSceneService', ['ShootingSetMeshService',
    function(ShootingSetMeshService){

	this.createSettingScene = function(){
        // Create a new Three.js scene
        var scene = new THREE.Scene();

        // Create a directional light to show off the object
        var light = new THREE.DirectionalLight( 0xffffff, 1.5);
        light.position.set(0, 0, 1);
        scene.add( light );

        var orientation = ShootingSetMeshService.createSetOrientation(
            new THREE.Vector3(100, 100, 0), // size
            new THREE.Vector3(0, 0, 0), // orientation
            new THREE.Vector3(0, 0, 0)); // offset
        scene.add(orientation);

        return scene;

	};

}]);
'use strict';

/* Controllers */

MyAppControllers.controller('notsandcrossCtrl', ['$scope',
  'NACCoinAndGrid','NaughtsAndCrossPlayer','NaughtsAndCrossGrid','CameraAndLighting',
    function($scope, NACCoinAndGrid, NaughtsAndCrossPlayer, NaughtsAndCrossGrid,
      CameraAndLighting) {
      var renderer = null, scene = null, container = null;
      var mouse = new THREE.Vector2();
      //var radius = 10, theta = 0;
      $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();
      $scope.errorMessage = null;
      $scope.makeMove = function(x,y,z){
        // Validate and Store the state in grid
        try{
          NaughtsAndCrossGrid.setPositionState(x,y,z,NaughtsAndCrossPlayer.getCurrentPlayer());
        }catch(error){
          $scope.errorMessage = error;
          return;
        }
        // Check whether the player has won
        if(NaughtsAndCrossGrid.hasThePlayerWon()){
          $scope.errorMessage = $scope.nextPlayer+" wins";
        }
        else{
          $scope.errorMessage = null;
        }
        // set the player state and toggle
        NaughtsAndCrossPlayer.setPositionAndToggle(x,y,z);
        //console.log("Error "+$scope.errorMessage);
        // Initialise the view
        $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();

      };
      $scope.undoMove = function(){
        var lastPlayedState = NaughtsAndCrossPlayer.getlastPlayedState();
        NaughtsAndCrossGrid.resetPositionState(lastPlayedState[0], lastPlayedState[1], lastPlayedState[2]);
        NaughtsAndCrossPlayer.undoLastMove();

        // Remove the last placed coin
        //removeCoin();

        $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();
        $scope.errorMessage = null;
      };

      function onLoad()
      {
        // Grab our container div
        container = document.getElementById("container");
        container.style.height = "400";
        //console.log("container value "+container.offsetWidth+" "+ container.offsetHeight+" "+container);
        // Create the Three.js renderer, add it to our div
        renderer = new THREE.WebGLRenderer( { antialias: true } );
        renderer.setSize(container.offsetWidth, container.offsetHeight);
        container.appendChild( renderer.domElement );

        // initialise camera
        CameraAndLighting.init(container.offsetWidth, container.offsetHeight, 10);
        //NACCoinAndGrid.init(.1,1);        

        // Create a new Three.js scene
        scene = new THREE.Scene();
        scene.add( CameraAndLighting.getLighting() );
        //console.log("The value of grid "+NACCoinAndGrid.getGrid());
        scene.add(NACCoinAndGrid.getGrid());
        // Add a mouse up handler to toggle the animation
        addEventHandlers(container);
        // Run our render loop
        run();
      }
      function run()
      {
        renderer.render(scene, CameraAndLighting.getCamera(scene.position));
        // Ask for another frame
        requestAnimationFrame(run);
      }
      function addEventHandlers(domElement)
      {
        window.addEventListener( 'keydown', onKeyDown, false);
      }
      function onKeyDown(e){
        //console.log("Event "+e.keyCode);
        if(e.keyCode === 37){CameraAndLighting.offsetCamera("left");}
        if(e.keyCode === 38){CameraAndLighting.offsetCamera("up");}
        if(e.keyCode === 39){CameraAndLighting.offsetCamera("right")}
        if(e.keyCode === 40){CameraAndLighting.offsetCamera("down")}
      }
      onLoad();
}]);
'use strict';

MyAppServices.service('NaughtsAndCrossGrid', function(){

    this.init = function(){
        // Create and initialise grid
        var gridSize = 3;
        this.gridState = new Array(gridSize);
        for(var i=0;i<gridSize;i++){
            this.gridState[i] = new Array(gridSize);
            for(var j=0;j<gridSize;j++){
                this.gridState[i][j] = new Array(gridSize);
                for(var k=0;k<gridSize;k++){
                    this.gridState[i][j][k] = 0;
                }
            }
        }
        this.winPositions = createAllPossibleWinPositions(gridSize);
        //console.log("Win positions "+JSON.stringify(this.winPositions));
        //console.log("Win positions Length "+this.winPositions.length);
	};

    // get the current state
    this.getPositionState = function(i,j,k){
	   return this.gridState[i][j][k];
    };
    this.resetPositionState = function(i,j,k){
        this.gridState[i][j][k]=0;
    };
    this.setPositionState = function(i,j,k,state){
        if(i<0 || i>2 || j<0 || j>2 || k<0 || k>2){
			throw "Invalid position. Enter value between 0-2";
        }
        if(this.gridState[i][j][k] !== 0){
			throw "Position already taken. Try New position";
        }
        this.gridState[i][j][k]=state;
    };
    this.hasThePlayerWon = function(){
        var winPos = this.winPositions;
        var gs = this.gridState;
        for(var i=0;i<winPos.length;i++){
            var p0 = winPos[i][0];
            var p1 = winPos[i][1];
            var p2 = winPos[i][2];
            //console.log(" winpos "+winPos[i]+" "+i);
            //console.log(" position "+p0+p1+p2)
            if(gs[p0[0]][p0[1]][p0[2]] !== 0 &&
               gs[p0[0]][p0[1]][p0[2]] === gs[p1[0]][p1[1]][p1[2]] &&
               gs[p2[0]][p2[1]][p2[2]] === gs[p1[0]][p1[1]][p1[2]]){
                return true;
            }
        }
        return false;
    };

    var createAllPossibleWinPositions = function(gridSize){
        // Create all possible win positions
        // Refer: http://www.cs.rochester.edu/~brown/242/assts/studprojs/ttt10.pdf
        // To detect a win, this program simply looks at every possible row, column and diagonal 
        // to see if any one player’s pieces occupy all 4 spaces. This is achieved using a series 
        // of conditionals. There are 76 different possibilities for a win (16 rows in each direction, 
        // 2 diagonals per face in each direction (which makes 12 faces), and then 4 corner-to-corner diagonals),
        // and this algorithm checks each one in sequence.
        // => 16 * 3 dimensions + 4 * 3 dimensions * 2 diagonals/face + 4 = 76
        // generic formula: 3*(N^2) + N*3*2 + 4
        var winPositions = [];
        // 3*N^2
        for(var i=0;i<gridSize;i++){
            for(var j=0;j<gridSize;j++){
                var winPositionX = new Array(gridSize);
                var winPositionY = new Array(gridSize);
                var winPositionZ = new Array(gridSize);
                for(var k=0;k<gridSize;k++){
                    winPositionX[k] = [k,i,j];
                    winPositionY[k] = [i,k,j];
                    winPositionZ[k] = [i,j,k];
                }
                winPositions.push(winPositionX);
                winPositions.push(winPositionY);
                winPositions.push(winPositionZ);
            }
        }
        // N*3*2
        for(var i=0;i<gridSize;i++){
            var winPostionDiagX1 = new Array(gridSize);
            var winPostionDiagX2 = new Array(gridSize);
            var winPostionDiagY1 = new Array(gridSize);
            var winPostionDiagY2 = new Array(gridSize);
            var winPostionDiagZ1 = new Array(gridSize);
            var winPostionDiagZ2 = new Array(gridSize);
            for(var k=0;k<gridSize;k++){
                winPostionDiagX1[k] = [i,k,k];
                winPostionDiagX2[k] = [i,2-k,2-k];
                winPostionDiagY1[k] = [k,i,k];
                winPostionDiagY2[k] = [2-k,i,2-k];
                winPostionDiagZ1[k] = [k,k,i];
                winPostionDiagZ2[k] = [2-k,2-k,i];
            }
            winPositions.push(winPostionDiagX1);
            winPositions.push(winPostionDiagX2);
            winPositions.push(winPostionDiagY1);
            winPositions.push(winPostionDiagY2);
            winPositions.push(winPostionDiagZ1);
            winPositions.push(winPostionDiagZ2);
        }
        // 4
        winPositions.push([[0,0,0], [1,1,1], [2,2,2]]);
        winPositions.push([[2,0,0], [1,1,1], [0,2,2]]);
        winPositions.push([[0,2,0], [1,1,1], [2,0,2]]);
        winPositions.push([[0,0,2], [1,1,1], [2,2,0]]);
        return winPositions;
    };

    // Initialise
    this.init();
});
'use strict';

MyAppServices.service('NaughtsAndCrossPlayer', ['NACCoinAndGrid',function(NACCoinAndGrid){

	this.init = function(){
		this.lastPlayer = "Player2";
		this.lastPlayedPosition = [0,0,0];
		this.newPositionSet = false;
	};

	this.getCurrentPlayer = function(){
		if(this.lastPlayer === "Player1") return "Player2";
		else return "Player1";
	};
	this.setPositionAndToggle = function(i,j,k){
		var coinType = "Naught";
		if(this.getCurrentPlayer() === "Player1"){
			coinType = "Cross";
		}
		this.lastPlayedCoin = NACCoinAndGrid.addCoin(coinType, [i,j,k]); 
		this.lastPlayedPosition = [i, j, k];
		this.lastPlayer = this.getCurrentPlayer();
		this.newPositionSet = true;
	};
	this.getlastPlayedState = function(){
		return this.lastPlayedPosition;
	};
	this.undoLastMove = function(){
		// toggle previous move only when new position is set
		if(this.newPositionSet){
			this.lastPlayer = this.getCurrentPlayer();
			this.newPositionSet=false;
			NACCoinAndGrid.removeCoin(this.lastPlayedCoin);
		}
	};
	this.init();
}]);
'use strict';

MyAppServices.service('NACCoinAndGrid', function(){

    this.init = function(pole_radius, naught_radius){
        // Now, create a Phong material to show shading; pass in the map
        // var material = new THREE.MeshPhongMaterial({ map: map });
        //var material = new THREE.MeshLambertMaterial( { color: 0xffff00 } );//new THREE.MeshBasicMaterial( { color: 0xffff00 } );
        //var map = THREE.ImageUtils.loadTexture( "img/flower.jpg" );
        //map.wrapS = map.wrapT = THREE.RepeatWrapping;
        //map.anisotropy = 16;

        //this.material = new THREE.MeshLambertMaterial( { ambient: 0xbbbbbb, map: map, side: THREE.DoubleSide } );
        //this.material = new THREE.MeshBasicMaterial( { color: 0xffffff } );
        //this.material = new THREE.MeshLambertMaterial( { color: 0xdddddd, shading: THREE.FlatShading } );
        //this.material = new THREE.MeshLambertMaterial( { color: 0xdddddd, shading: THREE.SmoothShading } );
        //this.material = new THREE.MeshNormalMaterial( );
        //this.material = new THREE.MeshBasicMaterial( { color: 0xffaa00, transparent: true, blending: THREE.AdditiveBlending } )
        /* this.material = new THREE.MeshPhongMaterial( { ambient: 0x030303, color: 0xdddddd, 
            specular: 0x009900, shininess: 30, shading: THREE.FlatShading, 
            map: map, transparent: false } ); */
        //this.material = new THREE.MeshNormalMaterial( { shading: THREE.SmoothShading } );
        //this.material = new THREE.MeshDepthMaterial()
        /*this.material = new THREE.MeshPhongMaterial( { color: 0x000000, specular: 0x666666, emissive: 0x00ff00, 
            ambient: 0x000000, shininess: 10, shading: THREE.SmoothShading, opacity: 1, transparent: false } );*/

        this.pole_radius = pole_radius;
        this.naught_radius = naught_radius;

        this.grid = createGrid(this.pole_radius, this.naught_radius);
    };

    var getCyclinder = function(material, radius, length){
        // Create the cylinder geometry
        var geometry = new THREE.CylinderGeometry( radius, radius, length, 10, 5, false);
        //(radiusTop, radiusBottom, height, radiusSegments, heightSegments, openEnded)
        // And put the geometry and material together into a mesh
        var cylinder = new THREE.Mesh(geometry, material);
        return cylinder;

    };
    var getNaught = function(naught_radius){
        var material = new THREE.MeshPhongMaterial( { color: 0x000000, specular: 0x666666, 
            emissive: 0x00ff00, ambient: 0x000000, shininess: 10, shading: THREE.SmoothShading, 
            opacity: 1, transparent: false } );
        // Create the cylinder geometry
        var geometry = new THREE.SphereGeometry(naught_radius, 40, 40);
        //(radius, widthSegments, heightSegments, phiStart, phiLength, thetaStart, thetaLength)
        // And put the geometry and material together into a mesh
        var sphere = new THREE.Mesh(geometry, material);
        return sphere;
    };

    var getCross = function(pole_radius, naught_radius){
        var material = new THREE.MeshPhongMaterial( { color: 0x000000, specular: 0x666666, 
            emissive: 0xff0000, ambient: 0x000000, shininess: 10, shading: THREE.SmoothShading, 
            opacity: 1, transparent: false } );
        // Create a group and add above together
        var cross = new THREE.Object3D();
        var pole_1 = getCyclinder(material, pole_radius, naught_radius);
        var pole_2 = getCyclinder(material, pole_radius, naught_radius);
        pole_2.rotation.x = Math.PI/2;
        var pole_3 = getCyclinder(material, pole_radius, naught_radius);
        pole_3.rotation.z = Math.PI/2;
        cross.add(pole_1);
        cross.add(pole_2);
        cross.add(pole_3);
        cross.rotation.x = Math.PI/4;
        cross.rotation.y = Math.PI/4;
        cross.rotation.z = Math.PI/4;
        return cross;
    };
    this.getGrid = function(){
        return this.grid;
    };

    this.addCoin = function(coinType, position){
        var coin = null;
        if(coinType === "Naught"){
            coin = getNaught(this.naught_radius);
        }
        else{
            coin = getCross(2*this.pole_radius, 2*this.naught_radius);
        }
        var common_offset = 2*(this.naught_radius+this.pole_radius);
        coin.position.x = (position[0]-1)*common_offset;
        coin.position.y = (position[1]-1)*common_offset;
        coin.position.z = (position[2]-1)*common_offset;
        this.grid.add(coin);
        return coin;
    };
    this.removeCoin = function(coin){
        this.grid.remove(coin);
    };

	var createGrid = function(pole_radius, naught_radius){

        var material = new THREE.MeshPhongMaterial( { color: 0x000000, specular: 0x666666, 
            emissive: 0x0b0077, ambient: 0x000000, shininess: 10, shading: THREE.SmoothShading, 
            opacity: 1, transparent: false } );

        /* Calcualtion for grid
            radius of not[ball] = x
            radius of grid poles = y
            Cube dimension: 3*2*x+2*2*y
            grid pole offsets: 
                - 2*x, 2*2*x+2*y
            length of pole = 3*2*x+2*2*y
        */
        var pole_length = 2*2*pole_radius+3*2*naught_radius;
        var cylinder = [];
        // Create a group and add above together
        var group = new THREE.Object3D();

        for(var i=0;i<12;i++){
            cylinder[i] = getCyclinder(material, pole_radius, pole_length);
            if(i<4)  cylinder[i].rotation.x = Math.PI/2;
            else if (i<8) cylinder[i].rotation.z = Math.PI/2;
            //else cylinder[i].rotation.z = Math.PI/2;
            //cylinder[i].position.x = i*2*pole_radius;
            group.add(cylinder[i]);
        }
        for(var j=0;j<2;j++){
            for(var k=0;k<2;k++){
                cylinder[2*j+k].position.x =
                    (2*k-1)*naught_radius+pole_radius;
                cylinder[2*j+k].position.y =
                    (2*j-1)*naught_radius+pole_radius;
            }
        }
        for(var j=0;j<2;j++){
            for(var k=0;k<2;k++){
                cylinder[4+2*j+k].position.z =
                    (2*k-1)*naught_radius+pole_radius;
                cylinder[4+2*j+k].position.y =
                    (2*j-1)*naught_radius+pole_radius;
            }
        }
        for(var j=0;j<2;j++){
            for(var k=0;k<2;k++){
                cylinder[8+2*j+k].position.z =
                    (2*k-1)*naught_radius+pole_radius;
                cylinder[8+2*j+k].position.x =
                    (2*j-1)*naught_radius+pole_radius;
            }
        }
        // Adding a invisible box
        /* Since not using ray casting commented out
        for(var i=0;i<3;i++){
            for(var j=0;j<3;j++){
                for(var k=0;k<3;k++){
                    var cube_width = 2*naught_radius;
                    var geometry = new THREE.CubeGeometry(cube_width, cube_width, cube_width, 1, 1, 1);
                    var inv_mat = new THREE.MeshPhongMaterial( {opacity: 0, transparent: true } );
                    var cube = new THREE.Mesh(geometry, inv_mat);
                    var common_offset = 2*(naught_radius+pole_radius);
                    cube.position.x = (i-1)*common_offset;
                    cube.position.y = (j-1)*common_offset;
                    cube.position.z = (k-1)*common_offset;
                    group.add(cube);
                }
            }
        } */
        // Add a axis helper to identify the orientation
        group.add(new THREE.AxisHelper(1));
        // trying iut text
        /* var textGeo = new THREE.TextGeometry( "Nitt", {

                    size: 0.2,
                    height: 0.2,
                    curveSegments: 4,

                    font: "optimer",
                    weight: "bold",
                    style:  "normal",

                    bevelThickness: 0.001,
                    bevelSize: 0.0015,
                    bevelEnabled: true,

                    material: 0,
                    extrudeMaterial: 1

        });
        var textMesh1 = new THREE.Mesh( textGeo, material );
        group.add(textMesh1); */
        return group;
	};
    this.init(0.1, 1);
});
'use strict';

MyAppServices.service('CameraAndLighting', function(){
	this.init = function(width, height, distance_from_scene){
		this.theta = 0;// Rotation angle about Y axis
		this.phi = 0; // Rotation angle about X Axis
		this.radius = distance_from_scene;
		this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 4000);
        /* camera = new THREE.OrthographicCamera( 10 / - 2, 10 / 2, 
          10 / 2, 10 / - 2, 1, 1000 ); */
        this.camera.position.set( 0, 0, distance_from_scene );
	};
	this.offsetCamera = function(direction){
		var offsetStep = 0.5;
		if(direction === "up"){ 
			this.phi += offsetStep;
			if(this.phi >= 90) {this.phi = 90;}
		}
		if(direction === "down"){ 
			this.phi -= offsetStep;
			if(this.phi <= -90) {this.phi = -90;}
		}
		if(direction === "left"){ this.theta -= offsetStep;}
		if(direction === "right"){ this.theta += offsetStep;}
	};
	this.getCamera = function(lookAtDirection){
		//console.log( " Angles "+this.theta+" "+this.phi);
		var thetaRad = THREE.Math.degToRad(this.theta);
		var phiRad = THREE.Math.degToRad(this.phi);
		var lookAtDirection_camera = lookAtDirection;
		this.camera.position.y = this.radius * Math.sin(phiRad);
		this.camera.position.x = this.radius * Math.cos(phiRad) * Math.sin(thetaRad);
		this.camera.position.z = this.radius * Math.cos(phiRad) * Math.cos(thetaRad);
		this.camera.lookAt(lookAtDirection);
		//console.log("New position "+this.phi+" "+this.theta);
		return this.camera;
	};
	this.getLighting = function(){
		// Create a group and add above together
        var group = new THREE.Object3D();
        group.add(new THREE.AmbientLight(0x404040));
        // Create a directional light to show off the object
        var light = new THREE.DirectionalLight( 0xffffff, 1.5);
        light.position.set(0, 0, 1);
        group.add(light);
        return group;
	}
});
'use strict';

/* Filters */

angular.module('myApp.filters', []).
  filter('interpolate', ['version', function(version) {
    return function(text) {
      return String(text).replace(/\%VERSION\%/mg, version);
    };
  }]);

'use strict';

/* Directives */


angular.module('myApp.directives', []).
  directive('appVersion', ['version', function(version) {
    return function(scope, elm, attrs) {
      elm.text(version);
    };
  }]);
