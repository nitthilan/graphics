'use strict';

MyAppServices.service('CameraAndLighting', function(){
	this.init = function(width, height, distance_from_scene){
		this.theta = 0;// Rotation angle about Y axis
		this.phi = 0; // Rotation angle about X Axis
		this.radius = distance_from_scene;
		this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 4000);
        /* camera = new THREE.OrthographicCamera( 10 / - 2, 10 / 2, 
          10 / 2, 10 / - 2, 1, 1000 ); */
        this.camera.position.set( 0, 0, distance_from_scene );
	};
	this.offsetCamera = function(direction){
		var offsetStep = 0.5;
		if(direction === "up"){ 
			this.phi += offsetStep;
			if(this.phi >= 90) {this.phi = 90;}
		}
		if(direction === "down"){ 
			this.phi -= offsetStep;
			if(this.phi <= -90) {this.phi = -90;}
		}
		if(direction === "left"){ this.theta -= offsetStep;}
		if(direction === "right"){ this.theta += offsetStep;}
	};
	this.getCamera = function(lookAtDirection){
		//console.log( " Angles "+this.theta+" "+this.phi);
		var thetaRad = THREE.Math.degToRad(this.theta);
		var phiRad = THREE.Math.degToRad(this.phi);
		var lookAtDirection_camera = lookAtDirection;
		this.camera.position.y = this.radius * Math.sin(phiRad);
		this.camera.position.x = this.radius * Math.cos(phiRad) * Math.sin(thetaRad);
		this.camera.position.z = this.radius * Math.cos(phiRad) * Math.cos(thetaRad);
		this.camera.lookAt(lookAtDirection);
		//console.log("New position "+this.phi+" "+this.theta);
		return this.camera;
	};
	this.getLighting = function(){
		// Create a group and add above together
        var group = new THREE.Object3D();
        group.add(new THREE.AmbientLight(0x404040));
        // Create a directional light to show off the object
        var light = new THREE.DirectionalLight( 0xffffff, 1.5);
        light.position.set(0, 0, 1);
        group.add(light);
        return group;
	}
});