'use strict';

/* Controllers */

MyAppControllers.controller('loginCtrl', ['$scope', '$resource', '$location', 'SessionService', 
    function($scope, $resource, $location, SessionService) {
    $scope.loginMessage = "Not logged in";
    $scope.login = function(username,password){
      var outer = this;
      console.log("Button clicked", outer.username, outer.password);
      
      var serverAuth = $resource('api/v1/session/login', {}, 
        { login: {method:'POST', params:{username:outer.username,password:outer.password}} });
      serverAuth.login(function(response){
        //console.log("Login successful: ", response);
        SessionService.setUserAuthenticated(true);
        //console.log("User authenticated ", SessionService.getUserAuthenticated());
        $location.path( "/reader" );
      }, 
      function(err){
        //console.log("Login", JSON.stringify(err));
        $scope.loginMessage = "Login Failed "+err.data.message;
      });
    };
  }]);
