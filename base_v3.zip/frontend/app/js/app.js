
window.routes =
{
  "/login": {
    templateUrl: 'partials/login.html', 
    controller: 'loginCtrl', 
    requireLogin: false
  },
  "/reader": {
    templateUrl: 'partials/reader.html', 
    controller: 'readerCtrl', 
    requireLogin: false
  },
  "/movie": {
    templateUrl: 'partials/movie.html', 
    controller: 'movieCtrl', 
    requireLogin: false
  },
  "/notsandcross": {
    templateUrl: 'partials/notsandcross.html', 
    controller: 'notsandcrossCtrl', 
    requireLogin: false
  }
};
// Declare app level module which depends on filters, and services
var MyApp = angular.module('myApp', ['myApp.filters', 'myApp.services', 'myApp.directives', 
                            'myApp.controllers', 'ngResource', 'ngSanitize', 'ui.event']);
var MyAppControllers = angular.module('myApp.controllers', []);
var MyAppServices = angular.module('myApp.services',[]);

MyApp
.config(['$routeProvider', function($routeProvider) {
  for(var path in window.routes){
    $routeProvider.when(path, window.routes[path]);
  }
  $routeProvider.otherwise({redirectTo: '/login'});
}])
.run(['$rootScope', 'SessionService',function($rootScope, SessionService){
  $rootScope.$on("$locationChangeStart", function(event, next, current) {
    for(var i in window.routes) {
      if(next.indexOf(i) != -1) {
        if(window.routes[i].requireLogin && !SessionService.getUserAuthenticated()) {
          alert("You need to be authenticated to see this page!");
          event.preventDefault();
        }
      }
    }
  });
}]);
