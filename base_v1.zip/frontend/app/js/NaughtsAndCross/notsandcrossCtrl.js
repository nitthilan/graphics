/* Controllers */
MyAppControllers.controller('notsandcrossCtrl', ['$scope',
  'NACCoinAndGrid','NaughtsAndCrossPlayer','NaughtsAndCrossGrid','CameraAndLighting',
    function($scope, NACCoinAndGrid, NaughtsAndCrossPlayer, NaughtsAndCrossGrid,
      CameraAndLighting) {
      'use strict';

      var renderer = null, scene = null, container = null;
      var mouse = new THREE.Vector2();
      //var radius = 10, theta = 0;
      $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();
      $scope.errorMessage = null;
      $scope.makeMove = function(x,y,z){
        // Get the xyz grid offsets
        var gridOffsets = CameraAndLighting.getGridOffsets();
        console.log("Offsets "+JSON.stringify(gridOffsets));
        // Validate and Store the state in grid
        try{
          NaughtsAndCrossGrid.setPositionState(gridOffsets[0],gridOffsets[1],gridOffsets[2],
            NaughtsAndCrossPlayer.getCurrentPlayer());
        }catch(error){
          $scope.errorMessage = error;
          return;
        }
        // Check whether the player has won
        if(NaughtsAndCrossGrid.hasThePlayerWon()){
          $scope.errorMessage = $scope.nextPlayer+" wins";
        }
        else{
          $scope.errorMessage = null;
        }
        // set the player state and toggle
        NaughtsAndCrossPlayer.setPositionAndToggle(gridOffsets[0],gridOffsets[1],gridOffsets[2]);
        //console.log("Error "+$scope.errorMessage);
        // Initialise the view
        $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();

      };
      $scope.undoMove = function(){
        var lastPlayedState = NaughtsAndCrossPlayer.getlastPlayedState();
        NaughtsAndCrossGrid.resetPositionState(lastPlayedState[0], lastPlayedState[1], lastPlayedState[2]);
        NaughtsAndCrossPlayer.undoLastMove();

        // Remove the last placed coin
        //removeCoin();

        $scope.nextPlayer = NaughtsAndCrossPlayer.getCurrentPlayer();
        $scope.errorMessage = null;
      };

      function onLoad()
      {
        // Grab our container div
        container = document.getElementById("container");
        container.style.height = "400";
        //console.log("container value "+container.offsetWidth+" "+ container.offsetHeight+" "+container);
        // Create the Three.js renderer, add it to our div
        renderer = new THREE.WebGLRenderer( { antialias: true } );
        renderer.setSize(container.offsetWidth, container.offsetHeight);
        container.appendChild( renderer.domElement );

        // initialise camera
        CameraAndLighting.init(container.offsetWidth, container.offsetHeight, 10);
        //NACCoinAndGrid.init(.1,1);        

        // Create a new Three.js scene
        scene = new THREE.Scene();
        scene.add( CameraAndLighting.getLighting() );
        //console.log("The value of grid "+NACCoinAndGrid.getGrid());
        scene.add(NACCoinAndGrid.getGrid());
        // Add a mouse up handler to toggle the animation
        addEventHandlers(container);
        // Run our render loop
        run();
      }
      function run()
      {
        renderer.render(scene, CameraAndLighting.getCamera(scene.position));
        // Ask for another frame
        requestAnimationFrame(run);
      }
      function addEventHandlers(domElement)
      {
        window.addEventListener( 'keydown', onKeyDown, false);
      }
      function onKeyDown(e){
        //console.log("Event "+e.keyCode);
        if(e.keyCode === 37){CameraAndLighting.offsetCamera("left");}
        if(e.keyCode === 38){CameraAndLighting.offsetCamera("up");}
        if(e.keyCode === 39){CameraAndLighting.offsetCamera("right");}
        if(e.keyCode === 40){CameraAndLighting.offsetCamera("down");}
      }
      onLoad();
}]);